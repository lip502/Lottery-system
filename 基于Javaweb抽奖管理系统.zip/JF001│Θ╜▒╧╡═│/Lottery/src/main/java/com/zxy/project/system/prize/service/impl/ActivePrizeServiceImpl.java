package com.zxy.project.system.prize.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zxy.project.system.prize.mapper.ActivePrizeMapper;
import com.zxy.project.system.prize.domain.ActivePrize;
import com.zxy.project.system.prize.service.IActivePrizeService;
import com.zxy.common.utils.text.Convert;

/**
 * 奖项设置Service业务层处理
 * 
 * @author zxy
 * @date 2021-05-18
 */
@Service
public class ActivePrizeServiceImpl implements IActivePrizeService 
{
    @Autowired
    private ActivePrizeMapper activePrizeMapper;

    /**
     * 查询奖项设置
     * 
     * @param id 奖项设置ID
     * @return 奖项设置
     */
    @Override
    public ActivePrize selectActivePrizeById(String id)
    {
        return activePrizeMapper.selectActivePrizeById(id);
    }

    /**
     * 查询奖项设置列表
     * 
     * @param activePrize 奖项设置
     * @return 奖项设置
     */
    @Override
    public List<ActivePrize> selectActivePrizeList(ActivePrize activePrize)
    {
        return activePrizeMapper.selectActivePrizeList(activePrize);
    }

    /**
     * 新增奖项设置
     * 
     * @param activePrize 奖项设置
     * @return 结果
     */
    @Override
    public int insertActivePrize(ActivePrize activePrize)
    {
        return activePrizeMapper.insertActivePrize(activePrize);
    }

    /**
     * 修改奖项设置
     * 
     * @param activePrize 奖项设置
     * @return 结果
     */
    @Override
    public int updateActivePrize(ActivePrize activePrize)
    {
        return activePrizeMapper.updateActivePrize(activePrize);
    }

    /**
     * 删除奖项设置对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteActivePrizeByIds(String ids)
    {
        return activePrizeMapper.deleteActivePrizeByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除奖项设置信息
     * 
     * @param id 奖项设置ID
     * @return 结果
     */
    @Override
    public int deleteActivePrizeById(String id)
    {
        return activePrizeMapper.deleteActivePrizeById(id);
    }
}
