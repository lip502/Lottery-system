package com.zxy.project.system.active.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zxy.project.system.active.mapper.ActiveMapper;
import com.zxy.project.system.active.domain.Active;
import com.zxy.project.system.active.service.IActiveService;
import com.zxy.common.utils.text.Convert;

/**
 * 活动管理Service业务层处理
 * 
 * @author zxy
 * @date 2021-05-07
 */
@Service
public class ActiveServiceImpl implements IActiveService 
{
    @Autowired
    private ActiveMapper activeMapper;

    /**
     * 查询活动管理
     * 
     * @param id 活动管理ID
     * @return 活动管理
     */
    @Override
    public Active selectActiveById(Integer id)
    {
        return activeMapper.selectActiveById(id);
    }

    /**
     * 查询活动管理列表
     * 
     * @param active 活动管理
     * @return 活动管理
     */
    @Override
    public List<Active> selectActiveList(Active active)
    {
        return activeMapper.selectActiveList(active);
    }

    /**
     * 新增活动管理
     * 
     * @param active 活动管理
     * @return 结果
     */
    @Override
    public int insertActive(Active active)
    {
        return activeMapper.insertActive(active);
    }

    /**
     * 修改活动管理
     * 
     * @param active 活动管理
     * @return 结果
     */
    @Override
    public int updateActive(Active active)
    {
        return activeMapper.updateActive(active);
    }

    /**
     * 删除活动管理对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteActiveByIds(String ids)
    {
        return activeMapper.deleteActiveByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除活动管理信息
     * 
     * @param id 活动管理ID
     * @return 结果
     */
    @Override
    public int deleteActiveById(Integer id)
    {
        return activeMapper.deleteActiveById(id);
    }
}
