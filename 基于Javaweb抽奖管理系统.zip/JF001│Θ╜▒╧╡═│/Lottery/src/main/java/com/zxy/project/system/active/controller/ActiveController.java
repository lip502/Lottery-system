package com.zxy.project.system.active.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import com.zxy.common.utils.NumberUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.zxy.framework.aspectj.lang.annotation.Log;
import com.zxy.framework.aspectj.lang.enums.BusinessType;
import com.zxy.project.system.active.domain.Active;
import com.zxy.project.system.active.service.IActiveService;
import com.zxy.framework.web.controller.BaseController;
import com.zxy.framework.web.domain.AjaxResult;
import com.zxy.common.utils.poi.ExcelUtil;
import com.zxy.framework.web.page.TableDataInfo;

/**
 * 活动管理Controller
 * 
 * @author zxy
 * @date 2021-05-07
 */
@Controller
@RequestMapping("/system/active")
public class ActiveController extends BaseController
{
    private String prefix = "system/active";

    @Autowired
    private IActiveService activeService;

    @RequiresPermissions("system:active:view")
    @GetMapping()
    public String active()
    {
        return prefix + "/active";
    }

    /**
     * 查询活动管理列表
     */
    @RequiresPermissions("system:active:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Active active)
    {
        startPage();
        List<Active> list = activeService.selectActiveList(active);
        return getDataTable(list);
    }

    /**
     * 导出活动管理列表
     */
    @RequiresPermissions("system:active:export")
    @Log(title = "活动管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Active active)
    {
        List<Active> list = activeService.selectActiveList(active);
        ExcelUtil<Active> util = new ExcelUtil<Active>(Active.class);
        return util.exportExcel(list, "active");
    }

    /**
     * 新增活动管理
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存活动管理
     */
    @RequiresPermissions("system:active:add")
    @Log(title = "活动管理", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Active active)
    {
        if (active.getActiveStatus().equals(1)) {
            Active ac = new Active();
            ac.setActiveStatus(1);
            activeService.selectActiveList(ac).forEach(a -> {
                a.setActiveStatus(0);
                activeService.updateActive(a);
            });
        }
        return toAjax(activeService.insertActive(active));
    }

    /**
     * 修改活动管理
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap)
    {
        Active active = activeService.selectActiveById(id);
        mmap.put("active", active);
        return prefix + "/edit";
    }

    /**
     * 修改保存活动管理
     */
    @RequiresPermissions("system:active:edit")
    @Log(title = "活动管理", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Active active)
    {
        if (active.getActiveStatus().equals(1)) {
            Active ac = new Active();
            ac.setActiveStatus(1);
            activeService.selectActiveList(ac).forEach(a -> {
                a.setActiveStatus(0);
                activeService.updateActive(a);
            });
        }
        return toAjax(activeService.updateActive(active));
    }

    /**
     * 删除活动管理
     */
    @RequiresPermissions("system:active:remove")
    @Log(title = "活动管理", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(activeService.deleteActiveByIds(ids));
    }

}