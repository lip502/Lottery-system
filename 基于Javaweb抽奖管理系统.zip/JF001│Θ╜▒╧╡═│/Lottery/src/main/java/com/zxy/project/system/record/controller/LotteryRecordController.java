package com.zxy.project.system.record.controller;

import java.util.*;

import com.zxy.common.constant.LotteryConstants;
import com.zxy.common.utils.DateUtils;
import com.zxy.common.utils.security.ShiroUtils;
import com.zxy.common.utils.uuid.LotteryUtils;
import com.zxy.project.system.active.domain.Active;
import com.zxy.project.system.active.service.IActiveService;
import com.zxy.project.system.prize.domain.ActivePrize;
import com.zxy.project.system.prize.service.IActivePrizeService;
import com.zxy.project.system.user.domain.User;
import com.zxy.project.system.user.service.IUserService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.zxy.framework.aspectj.lang.annotation.Log;
import com.zxy.framework.aspectj.lang.enums.BusinessType;
import com.zxy.project.system.record.domain.LotteryRecord;
import com.zxy.project.system.record.service.ILotteryRecordService;
import com.zxy.framework.web.controller.BaseController;
import com.zxy.framework.web.domain.AjaxResult;
import com.zxy.common.utils.poi.ExcelUtil;
import com.zxy.framework.web.page.TableDataInfo;

/**
 * 抽奖记录Controller
 *
 * @author zxy
 * @date 2021-05-07
 */
@Controller
@RequestMapping("/system/record")
public class LotteryRecordController extends BaseController
{
    private String prefix = "system/record";

    @Autowired
    private ILotteryRecordService lotteryRecordService;

    @Autowired
    private IActiveService activeService;

    @Autowired
    private IActivePrizeService activePrizeService;

    @Autowired
    private IUserService userService;

    @GetMapping()
    public String record()
    {
        return prefix + "/record";
    }


    @GetMapping("/my")
    public String myRecord()
    {
        return prefix + "/myRecord";
    }

    /**
     * 查询抽奖记录列表
     */
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(LotteryRecord lotteryRecord)
    {
        startPage();
        List<LotteryRecord> list = lotteryRecordService.selectLotteryRecordList(lotteryRecord);
        return getDataTable(list);
    }

    /**
     * 查询抽奖记录列表
     */
    @PostMapping("/myList")
    @ResponseBody
    public TableDataInfo myList(LotteryRecord lotteryRecord)
    {
        startPage();
        lotteryRecord.setUserId(ShiroUtils.getUserId().intValue());
        List<LotteryRecord> list = lotteryRecordService.selectLotteryRecordList(lotteryRecord);
        return getDataTable(list);
    }

    /**
     * 新增抽奖记录
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存抽奖记录
     */
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(LotteryRecord lotteryRecord)
    {
        List<String> codes = Arrays.asList(lotteryRecord.getSerialNumber().split(","));
        LotteryRecord createLottery;
        User user;
        ActivePrize activePrize = activePrizeService.selectActivePrizeById(lotteryRecord.getPrizeId());
        Date nowDate = DateUtils.getNowDate();
        for (String code : codes) {
            createLottery = new LotteryRecord();
            user = userService.selectUserByCode(code);
            createLottery.setUserId(user.getUserId().intValue());
            createLottery.setActiveId(lotteryRecord.getActiveId());
            createLottery.setPrizeStatus(1);
            createLottery.setPrizeType(activePrize.getPrizeName());
            createLottery.setPrizeValue(activePrize.getPrizeValue());
            createLottery.setPrizeTime(nowDate);
            lotteryRecordService.insertLotteryRecord(createLottery);
        }

        ActivePrize updateActive = new ActivePrize();
        updateActive.setId(lotteryRecord.getPrizeId());
        updateActive.setIfPrize(0);
        activePrizeService.updateActivePrize(updateActive);
        return toAjax(true);
    }

    /**
     * 修改抽奖记录
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap)
    {
        LotteryRecord lotteryRecord = lotteryRecordService.selectLotteryRecordById(id);
        mmap.put("lotteryRecord", lotteryRecord);
        return prefix + "/edit";
    }

    /**
     * 修改保存抽奖记录
     */
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(LotteryRecord lotteryRecord)
    {
        return toAjax(lotteryRecordService.updateLotteryRecord(lotteryRecord));
    }

    /**
     * 删除抽奖记录
     */
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(lotteryRecordService.deleteLotteryRecordByIds(ids));
    }
}
