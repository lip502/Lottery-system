package com.zxy.project.system.prize.domain;

import com.zxy.framework.aspectj.lang.annotation.Excel;
import com.zxy.framework.web.domain.BaseEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 奖项设置对象 active_prize
 * 
 * @author zxy
 * @date 2021-05-18
 */
public class ActivePrize extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** id */
    private String id;

    /** 活动id */
    @Excel(name = "活动id")
    private Integer activeId;

    /** 奖项名称 */
    @Excel(name = "奖项名称")
    private String prizeName;

    /** 奖项内容 */
    private String prizeValue;

    /** 奖项数量 */
    @Excel(name = "奖项数量")
    private Integer prizeNumber;

    /** 是否抽奖 */
    @Excel(name = "是否抽奖")
    private Integer ifPrize;

    /** 抽奖排序权重 */
    @Excel(name = "抽奖排序权重")
    private Integer orderNum;

    public String getPrizeValue() {
        return prizeValue;
    }

    public void setPrizeValue(String prizeValue) {
        this.prizeValue = prizeValue;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }
    public void setActiveId(Integer activeId)
    {
        this.activeId = activeId;
    }

    public Integer getActiveId()
    {
        return activeId;
    }
    public void setPrizeName(String prizeName)
    {
        this.prizeName = prizeName;
    }

    public String getPrizeName()
    {
        return prizeName;
    }
    public void setPrizeNumber(Integer prizeNumber)
    {
        this.prizeNumber = prizeNumber;
    }

    public Integer getPrizeNumber()
    {
        return prizeNumber;
    }
    public void setIfPrize(Integer ifPrize)
    {
        this.ifPrize = ifPrize;
    }

    public Integer getIfPrize()
    {
        return ifPrize;
    }
    public void setOrderNum(Integer orderNum)
    {
        this.orderNum = orderNum;
    }

    public Integer getOrderNum()
    {
        return orderNum;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("activeId", getActiveId())
            .append("prizeName", getPrizeName())
            .append("prizeNumber", getPrizeNumber())
            .append("ifPrize", getIfPrize())
            .append("orderNum", getOrderNum())
            .toString();
    }
}
