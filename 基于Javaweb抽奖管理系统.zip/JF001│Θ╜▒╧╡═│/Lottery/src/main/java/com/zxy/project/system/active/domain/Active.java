package com.zxy.project.system.active.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.zxy.framework.aspectj.lang.annotation.Excel;
import com.zxy.framework.web.domain.BaseEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 活动管理对象 active
 * 
 * @author zxy
 * @date 2021-05-07
 */
public class Active extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** id */
    private Integer id;

    /** 活动名称 */
    @Excel(name = "活动名称")
    private String activeName;

    /** 活动日期 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "活动日期", width = 30, dateFormat = "yyyy-MM-dd")
    private Date activeDate;

    /** 活动状态 */
    @Excel(name = "活动状态")
    private Integer activeStatus;

    public void setId(Integer id)
    {
        this.id = id;
    }

    public Integer getId()
    {
        return id;
    }
    public void setActiveName(String activeName)
    {
        this.activeName = activeName;
    }

    public String getActiveName()
    {
        return activeName;
    }
    public void setActiveDate(Date activeDate)
    {
        this.activeDate = activeDate;
    }

    public Date getActiveDate()
    {
        return activeDate;
    }
    public void setActiveStatus(Integer activeStatus)
    {
        this.activeStatus = activeStatus;
    }

    public Integer getActiveStatus()
    {
        return activeStatus;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("activeName", getActiveName())
            .append("activeDate", getActiveDate())
            .append("activeStatus", getActiveStatus())
            .toString();
    }
}
