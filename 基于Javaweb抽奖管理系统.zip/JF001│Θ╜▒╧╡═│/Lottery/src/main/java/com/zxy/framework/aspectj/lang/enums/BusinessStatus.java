package com.zxy.framework.aspectj.lang.enums;

/**
 * 操作状态
 * 
 * @author zxy
 *
 */
public enum BusinessStatus
{
    /**
     * 成功
     */
    SUCCESS,

    /**
     * 失败
     */
    FAIL,
}
