package com.zxy.project.system.prize.mapper;

import java.util.List;
import com.zxy.project.system.prize.domain.ActivePrize;

/**
 * 奖项设置Mapper接口
 * 
 * @author zxy
 * @date 2021-05-18
 */
public interface ActivePrizeMapper 
{
    /**
     * 查询奖项设置
     * 
     * @param id 奖项设置ID
     * @return 奖项设置
     */
    public ActivePrize selectActivePrizeById(String id);

    /**
     * 查询奖项设置列表
     * 
     * @param activePrize 奖项设置
     * @return 奖项设置集合
     */
    public List<ActivePrize> selectActivePrizeList(ActivePrize activePrize);

    /**
     * 新增奖项设置
     * 
     * @param activePrize 奖项设置
     * @return 结果
     */
    public int insertActivePrize(ActivePrize activePrize);

    /**
     * 修改奖项设置
     * 
     * @param activePrize 奖项设置
     * @return 结果
     */
    public int updateActivePrize(ActivePrize activePrize);

    /**
     * 删除奖项设置
     * 
     * @param id 奖项设置ID
     * @return 结果
     */
    public int deleteActivePrizeById(String id);

    /**
     * 批量删除奖项设置
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteActivePrizeByIds(String[] ids);
}
