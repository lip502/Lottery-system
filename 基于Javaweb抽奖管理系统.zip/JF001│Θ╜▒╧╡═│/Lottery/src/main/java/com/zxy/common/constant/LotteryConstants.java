package com.zxy.common.constant;

public enum LotteryConstants {
    NONE(-1,"未中奖"),
    GRAND(0,"特等奖"),
    FIRST(1,"一等奖"),
    SECOND(2,"二等奖"),
    THIRD(3,"三等奖"),;

    private int code;

    private String label;

    LotteryConstants(int code, String label) {
        this.code = code;
        this.label = label;
    }

    public static String getLabel(int code) {
        for (LotteryConstants lottery : LotteryConstants.values()) {
            if (lottery.getCode() == code) {
                return lottery.getLabel();
            }
        }
        return null;
    }

    public int getCode() {
        return code;
    }

    public String getLabel() {
        return label;
    }
}
