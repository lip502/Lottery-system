package com.zxy.project.system.prize.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.zxy.framework.aspectj.lang.annotation.Log;
import com.zxy.framework.aspectj.lang.enums.BusinessType;
import com.zxy.project.system.prize.domain.ActivePrize;
import com.zxy.project.system.prize.service.IActivePrizeService;
import com.zxy.framework.web.controller.BaseController;
import com.zxy.framework.web.domain.AjaxResult;
import com.zxy.common.utils.poi.ExcelUtil;
import com.zxy.framework.web.page.TableDataInfo;

/**
 * 奖项设置Controller
 * 
 * @author zxy
 * @date 2021-05-18
 */
@Controller
@RequestMapping("/system/prize")
public class ActivePrizeController extends BaseController
{
    private String prefix = "system/prize";

    @Autowired
    private IActivePrizeService activePrizeService;

    @GetMapping("/{activeId}")
    public String prize(@PathVariable("activeId") Integer activeId,ModelMap mmap)
    {
        mmap.put("activeId",activeId);
        return prefix + "/prize";
    }

    /**
     * 查询奖项设置列表
     */
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(ActivePrize activePrize)
    {
        startPage();
        List<ActivePrize> list = activePrizeService.selectActivePrizeList(activePrize);
        return getDataTable(list);
    }

    @GetMapping("/getListByActiveId")
    @ResponseBody
    public List getListByActiveId(Integer activeId)
    {
        ActivePrize activePrize = new ActivePrize();
        activePrize.setActiveId(activeId);
        return activePrizeService.selectActivePrizeList(activePrize);
    }

    /**
     * 新增奖项设置
     */
    @GetMapping("/add/{activeId}")
    public String add(@PathVariable("activeId") Integer activeId,ModelMap mmap)
    {
        mmap.put("activeId",activeId);
        return prefix + "/add";
    }

    /**
     * 新增保存奖项设置
     */
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(ActivePrize activePrize)
    {
        return toAjax(activePrizeService.insertActivePrize(activePrize));
    }

    /**
     * 修改奖项设置
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap)
    {
        ActivePrize activePrize = activePrizeService.selectActivePrizeById(id);
        mmap.put("activePrize", activePrize);
        return prefix + "/edit";
    }

    /**
     * 修改保存奖项设置
     */
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(ActivePrize activePrize)
    {
        return toAjax(activePrizeService.updateActivePrize(activePrize));
    }

    /**
     * 删除奖项设置
     */
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(activePrizeService.deleteActivePrizeByIds(ids));
    }
}
