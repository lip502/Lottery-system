package com.zxy.project.system.record.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zxy.project.system.record.mapper.LotteryRecordMapper;
import com.zxy.project.system.record.domain.LotteryRecord;
import com.zxy.project.system.record.service.ILotteryRecordService;
import com.zxy.common.utils.text.Convert;

/**
 * 抽奖记录Service业务层处理
 * 
 * @author zxy
 * @date 2021-05-07
 */
@Service
public class LotteryRecordServiceImpl implements ILotteryRecordService 
{
    @Autowired
    private LotteryRecordMapper lotteryRecordMapper;

    /**
     * 查询抽奖记录
     * 
     * @param id 抽奖记录ID
     * @return 抽奖记录
     */
    @Override
    public LotteryRecord selectLotteryRecordById(Integer id)
    {
        return lotteryRecordMapper.selectLotteryRecordById(id);
    }

    @Override
    public LotteryRecord selectLotteryRecordByUserIdAndActiveId(Integer userId, Integer activeId) {
        LotteryRecord lotteryRecord = new LotteryRecord();
        lotteryRecord.setUserId(userId);
        lotteryRecord.setActiveId(activeId);
        List<LotteryRecord> lotteryRecords = lotteryRecordMapper.selectLotteryRecordList(lotteryRecord);
        return lotteryRecords.size() > 0 ? lotteryRecords.get(0) : null;
    }

    /**
     * 查询抽奖记录列表
     * 
     * @param lotteryRecord 抽奖记录
     * @return 抽奖记录
     */
    @Override
    public List<LotteryRecord> selectLotteryRecordList(LotteryRecord lotteryRecord)
    {
        return lotteryRecordMapper.selectLotteryRecordList(lotteryRecord);
    }

    /**
     * 新增抽奖记录
     * 
     * @param lotteryRecord 抽奖记录
     * @return 结果
     */
    @Override
    public int insertLotteryRecord(LotteryRecord lotteryRecord)
    {
        return lotteryRecordMapper.insertLotteryRecord(lotteryRecord);
    }

    /**
     * 修改抽奖记录
     * 
     * @param lotteryRecord 抽奖记录
     * @return 结果
     */
    @Override
    public int updateLotteryRecord(LotteryRecord lotteryRecord)
    {
        return lotteryRecordMapper.updateLotteryRecord(lotteryRecord);
    }

    /**
     * 删除抽奖记录对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteLotteryRecordByIds(String ids)
    {
        return lotteryRecordMapper.deleteLotteryRecordByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除抽奖记录信息
     * 
     * @param id 抽奖记录ID
     * @return 结果
     */
    @Override
    public int deleteLotteryRecordById(Integer id)
    {
        return lotteryRecordMapper.deleteLotteryRecordById(id);
    }
}
