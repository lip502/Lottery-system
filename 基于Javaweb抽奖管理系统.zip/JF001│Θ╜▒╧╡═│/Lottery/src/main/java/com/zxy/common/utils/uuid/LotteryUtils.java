package com.zxy.common.utils.uuid;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LotteryUtils {

    private static final List<Integer> lottery = new ArrayList<>();
    static {
        lottery.add(0);
        for (int i = 0; i < 10; i++) {
            lottery.add(1);
        }
        for (int i = 0; i < 50; i++) {
            lottery.add(2);
        }
        for (int i = 0; i < 100; i++) {
            lottery.add(3);
        }
//        for (int i = 0; i < 200; i++) {
//            lottery.add(-1);
//        }
        Collections.shuffle(lottery);
    }

    public static int get() {
        int num = (int)(Math.random() * (lottery.size()-1));
        return lottery.get(num);
    }
}
