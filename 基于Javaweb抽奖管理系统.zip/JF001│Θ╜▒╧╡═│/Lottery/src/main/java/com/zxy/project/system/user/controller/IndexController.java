package com.zxy.project.system.user.controller;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;
import com.zxy.common.utils.security.ShiroUtils;
import com.zxy.project.system.active.domain.Active;
import com.zxy.project.system.active.service.IActiveService;
import com.zxy.project.system.record.domain.LotteryRecord;
import com.zxy.project.system.record.service.ILotteryRecordService;
import com.zxy.project.system.user.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.zxy.common.constant.ShiroConstants;
import com.zxy.common.utils.CookieUtils;
import com.zxy.common.utils.DateUtils;
import com.zxy.common.utils.ServletUtils;
import com.zxy.common.utils.StringUtils;
import com.zxy.common.utils.text.Convert;
import com.zxy.framework.config.ZxyConfig;
import com.zxy.framework.shiro.service.PasswordService;
import com.zxy.framework.web.controller.BaseController;
import com.zxy.framework.web.domain.AjaxResult;
import com.zxy.project.system.config.service.IConfigService;
import com.zxy.project.system.menu.domain.Menu;
import com.zxy.project.system.menu.service.IMenuService;
import com.zxy.project.system.user.domain.User;

/**
 * 首页 业务处理
 * 
 * @author zxy
 */
@Controller
public class IndexController extends BaseController
{
    @Autowired
    private IMenuService menuService;

    @Autowired
    private IConfigService configService;

    @Autowired
    private IUserService userService;

    @Autowired
    private IActiveService activeService;

    @Autowired
    private ILotteryRecordService lotteryRecordService;

    @Autowired
    private PasswordService passwordService;

    @Autowired
    private ZxyConfig zxyConfig;

    // 系统首页
    @GetMapping("/index")
    public String index(ModelMap mmap)
    {
        // 取身份信息
        User user = getSysUser();
        // 根据用户id取出菜单
        List<Menu> menus = menuService.selectMenusByUser(user);
        mmap.put("menus", menus);
        mmap.put("user", user);
        mmap.put("sideTheme", configService.selectConfigByKey("sys.index.sideTheme"));
        mmap.put("skinName", configService.selectConfigByKey("sys.index.skinName"));
        mmap.put("ignoreFooter", configService.selectConfigByKey("sys.index.ignoreFooter"));
        mmap.put("copyrightYear", zxyConfig.getCopyrightYear());
        mmap.put("isDefaultModifyPwd", initPasswordIsModify(user.getPwdUpdateDate()));
        mmap.put("isPasswordExpired", passwordIsExpiration(user.getPwdUpdateDate()));

        // 菜单导航显示风格
        String menuStyle = configService.selectConfigByKey("sys.index.menuStyle");
        // 移动端，默认使左侧导航菜单，否则取默认配置
        String indexStyle = ServletUtils.checkAgentIsMobile(ServletUtils.getRequest().getHeader("User-Agent")) ? "index" : menuStyle;
        
        // 优先Cookie配置导航菜单
        Cookie[] cookies = ServletUtils.getRequest().getCookies();
        for (Cookie cookie : cookies)
        {
            if (StringUtils.isNotEmpty(cookie.getName()) && "nav-style".equalsIgnoreCase(cookie.getName()))
            {
                indexStyle = cookie.getValue();
                break;
            }
        }
        String webIndex = "topnav".equalsIgnoreCase(indexStyle) ? "index-topnav" : "index";
        return webIndex;
    }

    // 锁定屏幕
    @GetMapping("/lockscreen")
    public String lockscreen(ModelMap mmap)
    {
        mmap.put("user", getSysUser());
        ServletUtils.getSession().setAttribute(ShiroConstants.LOCK_SCREEN, true);
        return "lock";
    }

    // 解锁屏幕
    @PostMapping("/unlockscreen")
    @ResponseBody
    public AjaxResult unlockscreen(String password)
    {
        User user = getSysUser();
        if (StringUtils.isNull(user))
        {
            return AjaxResult.error("服务器超时，请重新登陆");
        }
        if (passwordService.matches(user, password))
        {
            ServletUtils.getSession().removeAttribute(ShiroConstants.LOCK_SCREEN);
            return AjaxResult.success();
        }
        return AjaxResult.error("密码不正确，请重新输入。");
    }

    // 切换菜单
    @GetMapping("/system/menuStyle/{style}")
    public void menuStyle(@PathVariable String style, HttpServletResponse response)
    {
        CookieUtils.setCookie(response, "nav-style", style);
    }

    // 系统介绍
    @GetMapping("/system/main")
    public String main(ModelMap mmap)
    {
        List<User> users = userService.selectUserListNone(null);
        List<String> codes = users.stream()
                .map(User::getSerialNumber)
                .filter(StringUtils::isNotEmpty)
                .collect(Collectors.toList());


        Active active = new Active();
        active.setActiveStatus(1);
        List<Active> actives = activeService.selectActiveList(active);


        mmap.put("isActive",actives.size() > 0);

        if (actives.size() > 0) {
            mmap.put("active", actives.get(0));
            LotteryRecord lotteryRecord = lotteryRecordService.selectLotteryRecordByUserIdAndActiveId(ShiroUtils.getUserId().intValue(), actives.get(0).getId());
            mmap.put("isPrize", lotteryRecord != null && (lotteryRecord.getPrizeStatus() == 1));
            mmap.put("lotteryRecord",lotteryRecord);
        }

//        mmap.put("isAdmin",ShiroUtils.getSysUser().get);
        mmap.put("codes",codes);
        mmap.put("version", zxyConfig.getVersion());
        return "main";
    }
    
    // 检查初始密码是否提醒修改
    public boolean initPasswordIsModify(Date pwdUpdateDate)
    {
        Integer initPasswordModify = Convert.toInt(configService.selectConfigByKey("sys.account.initPasswordModify"));
        return initPasswordModify !=null && initPasswordModify == 1 && pwdUpdateDate == null;
    }
    
    // 检查密码是否过期
    public boolean passwordIsExpiration(Date pwdUpdateDate)
    {
        Integer passwordValidateDays = Convert.toInt(configService.selectConfigByKey("sys.account.passwordValidateDays"));
        if (passwordValidateDays !=null && passwordValidateDays > 0)
        {
            if (StringUtils.isNull(pwdUpdateDate))
            {
                // 如果从未修改过初始密码，直接提醒过期
                return true;
            }
            Date nowDate = DateUtils.getNowDate();
            return DateUtils.differentDaysByMillisecond(nowDate, pwdUpdateDate) > passwordValidateDays;
        }
        return false;
    }
}
