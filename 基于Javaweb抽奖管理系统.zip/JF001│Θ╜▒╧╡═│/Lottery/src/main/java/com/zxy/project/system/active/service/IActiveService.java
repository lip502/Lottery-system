package com.zxy.project.system.active.service;

import java.util.List;
import com.zxy.project.system.active.domain.Active;

/**
 * 活动管理Service接口
 * 
 * @author zxy
 * @date 2021-05-07
 */
public interface IActiveService 
{
    /**
     * 查询活动管理
     * 
     * @param id 活动管理ID
     * @return 活动管理
     */
    public Active selectActiveById(Integer id);

    /**
     * 查询活动管理列表
     * 
     * @param active 活动管理
     * @return 活动管理集合
     */
    public List<Active> selectActiveList(Active active);

    /**
     * 新增活动管理
     * 
     * @param active 活动管理
     * @return 结果
     */
    public int insertActive(Active active);

    /**
     * 修改活动管理
     * 
     * @param active 活动管理
     * @return 结果
     */
    public int updateActive(Active active);

    /**
     * 批量删除活动管理
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteActiveByIds(String ids);

    /**
     * 删除活动管理信息
     * 
     * @param id 活动管理ID
     * @return 结果
     */
    public int deleteActiveById(Integer id);
}
