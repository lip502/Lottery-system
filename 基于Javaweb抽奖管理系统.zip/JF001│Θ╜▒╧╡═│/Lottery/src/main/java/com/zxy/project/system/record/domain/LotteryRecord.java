package com.zxy.project.system.record.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.zxy.framework.aspectj.lang.annotation.Excel;
import com.zxy.framework.web.domain.BaseEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 抽奖记录对象 lottery_record
 * 
 * @author zxy
 * @date 2021-05-07
 */
public class LotteryRecord extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** id */
    private Integer id;

    /** 用户id */
    private Integer userId;

    private String userName;

    /**
     * 编号
     */
    private String serialNumber;

    /** 活动id */
    private Integer activeId;

    private String activeName;

    /** 中奖状态 */
    private Integer prizeStatus;

    private String prizeId;

    /** 奖项类型 */
    private String prizeType;

    /** 奖项内容 */
    private String prizeValue;

    /** 抽奖时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date prizeTime;

    public String getPrizeId() {
        return prizeId;
    }

    public void setPrizeId(String prizeId) {
        this.prizeId = prizeId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getActiveName() {
        return activeName;
    }

    public void setActiveName(String activeName) {
        this.activeName = activeName;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public Integer getId()
    {
        return id;
    }
    public void setUserId(Integer userId)
    {
        this.userId = userId;
    }

    public Integer getUserId()
    {
        return userId;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public void setActiveId(Integer activeId)
    {
        this.activeId = activeId;
    }

    public Integer getActiveId()
    {
        return activeId;
    }
    public void setPrizeStatus(Integer prizeStatus)
    {
        this.prizeStatus = prizeStatus;
    }

    public Integer getPrizeStatus()
    {
        return prizeStatus;
    }
    public void setPrizeType(String prizeType)
    {
        this.prizeType = prizeType;
    }

    public String getPrizeType()
    {
        return prizeType;
    }
    public void setPrizeValue(String prizeValue)
    {
        this.prizeValue = prizeValue;
    }

    public String getPrizeValue()
    {
        return prizeValue;
    }
    public void setPrizeTime(Date prizeTime)
    {
        this.prizeTime = prizeTime;
    }

    public Date getPrizeTime()
    {
        return prizeTime;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("userId", getUserId())
            .append("activeId", getActiveId())
            .append("prizeStatus", getPrizeStatus())
            .append("prizeType", getPrizeType())
            .append("prizeValue", getPrizeValue())
            .append("prizeTime", getPrizeTime())
            .toString();
    }
}
